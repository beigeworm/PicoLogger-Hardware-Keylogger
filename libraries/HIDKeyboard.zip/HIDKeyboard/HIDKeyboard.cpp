
#ifndef USE_TINYUSB
  //if not using TinyUSB then default to the standard Arduino routines.
  #include <HID.h>
  #include <Keyboard.h>
  #include <Mouse.h>
#else

  #include <Adafruit_TinyUSB.h>
  #include <HIDKeyboard.h>
  
  #define US_KEYBOARD

  #ifdef US_KEYBOARD
  #include "layouts/US/us.h"
  #endif
  #ifdef ES_KEYBOARD
  #include "layouts/ES/es.h"
  #endif
  #ifdef UK_KEYBOARD
  #include "layouts/UK/uk.h"
  #endif
  #ifdef FR_KEYBOARD
  #include "layouts/FR/fr.h"
  #endif
  #ifdef DK_KEYBOARD
  #include "layouts/DK/dk.h"
  #endif
  #ifdef DE_KEYBOARD
  #include "layouts/DE/de.h"
  #endif
  #ifdef IT_KEYBOARD
  #include "layouts/IT/it.h"
  #endif
  #ifdef PT_KEYBOARD
  #include "layouts/PT/pt.h"
  #endif
  #ifdef FI_KEYBOARD
  #include "layouts/FI/fi.h"
  #endif
  #ifdef BE_KEYBOARD
  #include "layouts/BE/be.h"
  #endif
  #ifdef BR_KEYBOARD
  #include "layouts/BR/br.h"
  #endif
  #ifdef TR_KEYBOARD
  #include "layouts/TR/tr.h"
  #endif
  
  #define RID_KEYBOARD 1
  #define RID_MOUSE 2
  
  // GENERIC CONF
  uint8_t const desc_hid_report[] =
  {
    TUD_HID_REPORT_DESC_KEYBOARD( HID_REPORT_ID(RID_KEYBOARD) ),
    TUD_HID_REPORT_DESC_MOUSE( HID_REPORT_ID(RID_MOUSE) ) // ONLY FOR USBHOST MOUSE ATTACK
  };
  
  // ONLY FOR BYPASS INTERFACE WHITELIST: https://www.youtube.com/watch?v=sc4aZd3XP70
  /*uint8_t const desc_system_report[] =
  {
    TUD_HID_REPORT_DESC_SYSTEM_CONTROL( HID_REPORT_ID(2) ),
    TUD_HID_REPORT_DESC_CONSUMER( HID_REPORT_ID(1) ),
  };*/

  // GENERIC CONF
  Adafruit_USBD_HID usb_hid;
  
  // ONLY FOR BYPASS INTERFACE WHITELIST: https://www.youtube.com/watch?v=sc4aZd3XP70
  //Adafruit_USBD_HID usb_hid(desc_hid_report, sizeof(desc_hid_report), HID_ITF_PROTOCOL_KEYBOARD, 2, false);
  //Adafruit_USBD_HID usb_keyboard(desc_system_report, sizeof(desc_system_report), HID_ITF_PROTOCOL_NONE, 2, false);
  
  TinyKeyboard_::TinyKeyboard_(void) {
  }

  TinyMouse_::TinyMouse_(void) {
  }
  
   void TinyKeyboard_::begin(void)
  {
    usb_hid.setPollInterval(2);
    usb_hid.setReportDescriptor(desc_hid_report, sizeof(desc_hid_report));
    usb_hid.begin();
    //usb_keyboard.begin(); // ONLY FOR BYPASS INTERFACE WHITELIST: https://www.youtube.com/watch?v=sc4aZd3XP70
    while( !TinyUSBDevice.mounted() ) delay(1);
  }
  
  void TinyMouse_::begin(void) {
    _buttons = 0;
    usb_hid.setPollInterval(2);
    usb_hid.setReportDescriptor(desc_hid_report, sizeof(desc_hid_report));
    usb_hid.begin();
    while( !USBDevice.mounted() ) delay(1);
  }
  
  void TinyMouse_::move (int8_t x, int8_t y, int8_t wheel) {
    if ( USBDevice.suspended() )  {
      USBDevice.remoteWakeup();
    }
    while(!usb_hid.ready()) delay(1);
    usb_hid.mouseReport(RID_MOUSE,_buttons,x,y,wheel,0);
  }
  
  void TinyMouse_::end(void) 
  {
  }
  
  void TinyMouse_::click(uint8_t b)
  {
    _buttons = b;
    move(0,0,0);
    _buttons = 0;
    move(0,0,0);
  }
  
  void TinyMouse_::buttons(uint8_t b)
  {
    if (b != _buttons)
    {
      _buttons = b;
      move(0,0,0);
    }
  }
  
  void TinyMouse_::press(uint8_t b) 
  {
    buttons(_buttons | b);
  }
  
  void TinyMouse_::release(uint8_t b)
  {
    buttons(_buttons & ~b);
  }
  
  bool TinyMouse_::isPressed(uint8_t b)
  {
    if ((b & _buttons) > 0) 
      return true;
    return false;
  }
  
  TinyMouse_ Mouse;//create an instance of the Mouse object
  
  void TinyKeyboard_::end(void)
  {
  }
  
  void TinyKeyboard_::sendReport(KeyReport* keys)
  {
    if ( TinyUSBDevice.suspended() )  {
      TinyUSBDevice.remoteWakeup();
    }
    while(!usb_hid.ready()) delay(1);
    usb_hid.keyboardReport(RID_KEYBOARD,keys->modifiers,keys->keys);
    delay(2);
  }
  
  // press() adds the specified key (printing, non-printing, or modifier)
  // to the persistent key report and sends the report.  Because of the way 
  // USB HID works, the host acts like the key remains pressed until we 
  // call release(), releaseAll(), or otherwise clear the report and resend.
  size_t TinyKeyboard_::press(uint8_t k)
  {
    uint8_t i;

	if(k>=0xB0 && k<=0xDA){			//it's a non-printing key
		if(k>=0xB5 && k<=0xBE){		//0xB5-0xBE reserved for special non printing keys asigned manually
			if(k==0xB5) k=0x65;	//0xB5 ==> 0x76 (MENU key)
			if(k==0xB6) k=0x46;	//0xB6 ==> 0x46 (PRINT Screen key)
		}
		else{
			k = k - 136;
		}
	}
	else {
	if(k>=0x80 && k<=0x87){			//it's a modifier
		_keyReport.modifiers |= (1<<(k-128));
		k = 0;
	}
	else{					//it's a printable key

	k = pgm_read_byte(_asciimap + k);

	if (k & 0x80) {				// it's a capital letter or other character reached with shift
		_keyReport.modifiers |= 0x02;	// the left shift modifier
		k &= 0x7F;
	}
	if (k & 0x40) {				// altgr modifier (RIGHT_ALT)
		_keyReport.modifiers |= 0x40;	// the left shift modifier
		k &= 0x3F;
	}
	if (k == 0x03) { // special case 0x64
		k = 0x64;
	}
	}
	}

	// Add k to the key report only if it's not already present
	// and if there is an empty slot.
	if (_keyReport.keys[0] != k && _keyReport.keys[1] != k &&
		_keyReport.keys[2] != k && _keyReport.keys[3] != k &&
		_keyReport.keys[4] != k && _keyReport.keys[5] != k) {
		
		for (i=0; i<6; i++) {
			if (_keyReport.keys[i] == 0x00) {
				_keyReport.keys[i] = k;
				break;
			}
		}
		if (i == 6) {
			setWriteError();
			return 0;
		}	
	}
	sendReport(&_keyReport);
	return 1;
  }
  
  size_t TinyKeyboard_::rawpress(uint8_t k, uint8_t rawmodifiers)
  {
    uint8_t i;

    _keyReport.modifiers = rawmodifiers;	

    if (_keyReport.keys[0] != k && _keyReport.keys[1] != k &&
      _keyReport.keys[2] != k && _keyReport.keys[3] != k &&
      _keyReport.keys[4] != k && _keyReport.keys[5] != k) {
		
      for (i=0; i<6; i++) {
        if (_keyReport.keys[i] == 0x00) {
	  _keyReport.keys[i] = k;
	  break;
	}
      }
		
      if (i == 6) {
        setWriteError();
	return 0;
      }	
    }
	
    sendReport(&_keyReport);
    return 1;
}
  
  // release() takes the specified key out of the persistent key report and
  // sends the report.  This tells the OS the key is no longer pressed and that
  // it shouldn't be repeated any more.
  size_t TinyKeyboard_::release(uint8_t k)
  {
    uint8_t i;

	if(k>=0xB0 && k<=0xDA){			//it's a non-printing key
		if(k>=0xB5 && k<=0xBE){		//0xB5-0xBE reserved for special non printing keys asigned manually
			if(k==0xB5) k=0x65;	//0xB5 ==> 0x76 (MENU key)
			if(k==0xB6) k=0x46;	//0xB6 ==> 0x46 (PRINT Scr key)
		}
		else{
			k = k - 136;
		}
	}
	else {
	if(k>=0x80 && k<=0x87){			//it's a modifier
		_keyReport.modifiers &= ~(1<<(k-128));
		k = 0;
	}
	else{					//it's a printable key

	k = pgm_read_byte(_asciimap + k);

	if (k & 0x80) {					// it's a capital letter or other character reached with shift
		_keyReport.modifiers &= ~(0x02);	// the left shift modifier
		k &= 0x7F;
	}
	if (k & 0x40) {
		_keyReport.modifiers &= ~(0x40);       // the altgr shift modifier
		k &= 0x3F;
	}
	if (k == 0x03) { // special case 0x64
		k = 0x64;
	}

	if (k >= 136) {			// it's a non-printing key (not a modifier)
		k = k - 136;
	}
	}
	}

	// Test the key report to see if k is present.  Clear it if it exists.
	// Check all positions in case the key is present more than once (which it shouldn't be)
	for (i=0; i<6; i++) {
		if (0 != k && _keyReport.keys[i] == k) {
			_keyReport.keys[i] = 0x00;
		}
	}

	sendReport(&_keyReport);
	return 1;
  }
  
  size_t TinyKeyboard_::rawrelease(uint8_t k, uint8_t rawmodifiers)
  {
    uint8_t i;

    _keyReport.modifiers = rawmodifiers;

    for (i=0; i<6; i++) {
      if (0 != k && _keyReport.keys[i] == k) {
        _keyReport.keys[i] = 0x00;
      }
    }

    sendReport(&_keyReport);
    return 1;
}

  
  void TinyKeyboard_::releaseAll(void)
  {
    _keyReport.keys[0] = 0;
    _keyReport.keys[1] = 0; 
    _keyReport.keys[2] = 0;
    _keyReport.keys[3] = 0; 
    _keyReport.keys[4] = 0;
    _keyReport.keys[5] = 0; 
    _keyReport.modifiers = 0;
    sendReport(&_keyReport);
  }
  
  size_t TinyKeyboard_::write(uint8_t c)
  {
    uint8_t p = press(c);  // Keydown
    release(c);            // Keyup
    return p;              // just return the result of press() since release() almost always returns 1
  }
  
  size_t TinyKeyboard_::write(const uint8_t *buffer, size_t size) {
    size_t n = 0;
    while (size--) {
      if (*buffer != '\r') {
        if (write(*buffer)) {
          n++;
        } else {
          break;
        }
      }
      buffer++;
    }
    return n;
  }
  TinyKeyboard_ Keyboard;//create an instance of the Keyboard object
#endif
